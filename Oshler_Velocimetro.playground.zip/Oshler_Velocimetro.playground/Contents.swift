// WK04: Peer-graded Assignment: Un velocímetro de un automóvil digital
// Osler Villegas - Oshler

import UIKit

// Declara la enumeración: Velocidades, sus valores serán de tipo Int

enum Velocidades : Int {
    
//La enumeración Velocidades cuenta con sus elementos y sus respectivos valores
    
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120

// Declarar un inicializador que recibe un velocidad: init( velocidadInicial : Velocidades )
// El inicializador se debe asignar a self el valor de velocidadInicial
    
    init(velocidadInicial : Velocidades){
        self = velocidadInicial
    }
    
}

//Declara la clase: Auto, con sus atributos

class Auto{
    var velocidad : Velocidades
    
    init(){
        self.velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
    }

// La función cambioDeVelocidad, cambia el valor de velocidad a la siguiente velocidad gradua

func cambioDeVelocidad()->(velocidadActual: Int, velocidadEnCadena: String){
    var velocidadEnCadena : String = ""
    var velocidadActual : Int
    
    switch velocidad {
        
    case Velocidades.Apagado:
        velocidadActual = velocidad.rawValue
        velocidadEnCadena = "Apagado"
        
        velocidad = Velocidades.VelocidadBaja
        
    case Velocidades.VelocidadBaja:
        velocidadActual = velocidad.rawValue
        velocidadEnCadena = "Velociad Baja"
        
        velocidad = Velocidades.VelocidadMedia
    
    case Velocidades.VelocidadMedia:
        velocidadActual = velocidad.rawValue
        velocidadEnCadena = "Velociad Media"
        
        velocidad = Velocidades.VelocidadAlta
        
    case Velocidades.VelocidadAlta:
        velocidadActual = velocidad.rawValue
        velocidadEnCadena = "Velociad Alta"
        
        velocidad = Velocidades.VelocidadMedia
    
    }
    
    return (velocidadActual, velocidadEnCadena)
}
}

var auto = Auto()

for i in 1...20{
    var velocity = auto.cambioDeVelocidad()
    print ("Actual: \(velocity.velocidadActual) km/h \(velocity.velocidadEnCadena)")
}
