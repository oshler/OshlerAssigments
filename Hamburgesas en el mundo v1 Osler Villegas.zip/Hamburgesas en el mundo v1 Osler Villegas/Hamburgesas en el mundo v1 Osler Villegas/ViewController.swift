//
//  ViewController.swift
//  Hamburgesas en el mundo v1 Osler Villegas
//
//  Created by Osler Villegas on 8/13/17.
//  Copyright © 2017 Oshler. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let paiseslist = CollecionDePaises()
    let hamburgesaslist = CollecionDeHamburgesas()
    let precioslist = CollecionDePrecios()
    let coloreslist = Colores()

    @IBOutlet weak var pais: UILabel!
    @IBOutlet weak var hamburgesa: UILabel!
    @IBOutlet weak var precio: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func quieroUnaHambugersa(sender: AnyObject) {
        
        pais.text = paiseslist.obtenerPais()
        hamburgesa.text = hamburgesaslist.obtenerHamburgesa()
        precio.text = precioslist.obtenerPrecio()
        
        let colorAleatorio = coloreslist.regresaColorAleatorio()
        view.backgroundColor = colorAleatorio
        view.tintColor = colorAleatorio
        
    }

}

