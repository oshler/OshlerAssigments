//
//  Datos.swift
//  Hamburgesas en el mundo v1 Osler Villegas
//
//  Created by Osler Villegas on 8/13/17.
//  Copyright © 2017 Oshler. All rights reserved.
//

import Foundation
import UIKit

class CollecionDePaises{
    let paises : [String] = ["US","México", "Alemania", "Cánada", "Brazil", "Francia", "España", "Colombia", "Argentina", "Chile", "China", "Japón", "Tailandia", "Suiza", "Inglaterra", "Egipto", "Sufáfrica", "Australia", "India", "Italia"]
    
    func obtenerPais() -> String{
        let posicionPaises = Int (arc4random()) % 20
        return paises[posicionPaises]
    }
    
}

class CollecionDeHamburgesas{
    let hamburgesas : [String] = ["Jalapeño Bacon Cheese Burger","Latin Macho Burger", "Wurst Burger","Mapple Burger", "Hamburgao", "Ratatouille Burger", "Paella Burger", "Paisa Burger", "Chimichurri Burger", "Humitas Burger", "Rice Burger", "Sushi Burger", "Noddle Burger", "Chocolate Burger", "Fish & Fries Burger", "Pyramid Burger", "Animal Burger", "Kangaroo Burger", "Elephant Burger", "Pepperoni Burger"]
    
    func obtenerHamburgesa() -> String{
        let posicionHamburgesa = Int (arc4random()) % 20
        return hamburgesas[posicionHamburgesa]
    }
    
}

class CollecionDePrecios{
    let precios : [String] = ["$25.45", "$52.10", "$1.00", "$100.00", "88.88", "$46.78", "$122.34", "$98.76", "$39.54", "$73.48", "$85.32", "$99.99", "$12.58", "$33.89", "$49.12", "$62.73", "$19.28", "$91.82", "$45.67", "$76.54"]
    
    func obtenerPrecio() -> String{
        let posicionPrecio = Int (arc4random()) % 20
        return precios[posicionPrecio]
    }
    
}

struct Colores{
    let colores = [ UIColor(red:236/255.0, green: 28/255.0, blue: 14/255.0, alpha: 1),
                    UIColor(red:58/255.0, green: 228/255.0, blue: 45/255.0, alpha: 1),
                    UIColor(red:58/255.0, green: 55/255.0, blue: 213/255.0, alpha: 1),
                    UIColor(red:203/255.0, green: 127/255.0, blue: 66/255.0, alpha: 1),
                    UIColor(red:86/255.0, green: 120/255.0, blue: 186/255.0, alpha: 1),
                    UIColor(red:193/255.0, green: 66/255.0, blue: 186/255.0, alpha: 1),
                    UIColor(red:15/255.0, green: 250/255.0, blue: 250/255.0, alpha: 1),
                    UIColor(red:250/255.0, green: 15/255.0, blue: 250/255.0, alpha: 1),
                    UIColor(red:250/255.0, green: 250/255.0, blue: 15/255.0, alpha: 1),
                    UIColor(red:139/255.0, green: 134/255.0, blue: 132/255.0, alpha: 1)]
    
    func regresaColorAleatorio() -> UIColor{
        let posicionColor = Int (arc4random()) % colores.count
        return colores[posicionColor]
    }
}